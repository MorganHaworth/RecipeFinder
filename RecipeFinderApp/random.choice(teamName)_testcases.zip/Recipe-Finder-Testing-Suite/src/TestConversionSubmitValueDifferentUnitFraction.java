

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class TestConversionSubmitValueDifferentUnitFraction {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.chrome.driver", "lib/win/chromedriver.exe");
	driver = new ChromeDriver();
    baseUrl = "https://www.google.com/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testConversionSubmitValueDifferentUnitFraction() throws Exception {
    driver.get("http://spicymeatballs.tech:5000/convert/");
    Thread.sleep(500);
    driver.findElement(By.name("unitCount")).click();
    driver.findElement(By.name("unitCount")).clear();
    driver.findElement(By.name("unitCount")).sendKeys("4");
    driver.findElement(By.xpath("//form[@id='convForm']/div/button/div/div/div")).click();
    driver.findElement(By.xpath("//form[@id='convForm']/div/div/div/ul/li[7]/a/span")).click();
    new Select(driver.findElement(By.name("fromUnit"))).selectByVisibleText("Teaspoon");
    Thread.sleep(500);
    driver.findElement(By.xpath("//form[@id='convForm']/div[2]/button/div/div/div")).click();
    driver.findElement(By.xpath("//form[@id='convForm']/div[2]/div/div/ul/li[6]/a")).click();
    new Select(driver.findElement(By.name("toUnit"))).selectByVisibleText("Tablespoon");
    Thread.sleep(500);
    driver.findElement(By.xpath("//button[@value='Submit']")).click();
    Thread.sleep(2000);
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
